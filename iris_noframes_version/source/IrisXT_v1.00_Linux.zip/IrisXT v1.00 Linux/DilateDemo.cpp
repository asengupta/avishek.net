#include <cstdlib>
#include "BitmapStreamer.h"
#include "KernelMatrix.h"
#include "NonkernelAlgorithms.h"
#include "MiscRoutines.h"
#include "HoughTransform.h"
#include "AutomataEdge.h"
#include "AutomataSkeleton.h"
#include "EdgeDetectors.h"
#include "SpecialKernels.h"

using namespace Comrade::IrisFoundation;
using namespace Comrade::IrisXT;

int main(int argc,char* argv[])
{
    // Compatibility note: For Linux systems, omit ios_base::binary. Won't work otherwise.
    
    BitmapStreamer x;
    x.byte_reader.reader.open("avishek.bmp",std::ios_base::in|std::ios_base::ate);
    x.byte_reader.writer.open("avishek.bmp",std::ios_base::in|std::ios_base::out);

    if (x.byte_reader.reader.is_open()==true)
    {
        cout<<"File could be opened...";
    }

    int ys=x.byte_reader.read_field(OFFSET,SZ_OFFSET);
    cout<<ys<<endl;
    int xsz=x.byte_reader.read_field(BMP_WIDTH,SZ_BMP_WIDTH);
    int ysz=x.byte_reader.read_field(BMP_HEIGHT,SZ_BMP_HEIGHT);
    int comp=x.byte_reader.read_field(COMPRESSION,SZ_COMPRESSION);
    
    cout<<"This is "<<xsz<<" "<<ysz<<".Compression is "<<comp<<endl;

    int lim=5;//atoi(argv[1]);
    int quo=19;//atoi(argv[2]);
    double thresh=.09;//atof(argv[3]);

    //cout<<"Limit is "<<lim<<endl;
    //cout<<"Threshold is "<<thresh<<endl;

    KernelMatrix vec(11,11);//atoi(argv[1]),atoi(argv[1]));
    KernelGenerator::generate_Gaussian(&vec,6);//atof(argv[3]));
    // Hint: Use 11,6,1 as cmd line arguments - in that order.

    double bmat[]={ 1, 0, 0, 0, 0,
                    0, 0,-1, 0, 0,
                    0,-1, 4,-1, 0,
                    0, 0,-1, 0, 0,
                    0, 0, 0, 0, 0};

    KernelMatrix mat(5,5);
    mat.set_values(bmat);

    KernelOperator op;
    op.assign_kernel(&mat);
    op.set_factor(1);//atof(argv[2]));

    //SequenceAnalyser<double> seq;
    CA_EdgeDetector det;
    CA_Skeletoniser skel;
    StraightLineDetector line_det(20,20);

    det.set_check_limits(lim,lim);
    det.set_quorum(quo);
    det.set_threshold(thresh);

    //seq.set_tolerance(.2);
    //seq.set_trigger_fraction(.2);

    //int ccx=8,ccy=6;
    //double rad1[25],rad2[25];

    EdgeDetectorManager etor;
    AlgorithmManager god;
    god.copy_to_output=true;

    Buffer<RGB> op_buf(&x);
    Buffer<RGB> ip_buf(&x);
    //Buffer<RGB> cc(ccx,ccy);
    //Buffer<HSLstruct> check(&x);
    //Buffer<HSLstruct> checkdash(&y);

    op.assign_buffer_ptrs(&ip_buf,&op_buf);
    RGB_BufferManager man1,man2;

    man1.assign_buffer(&ip_buf);
    man2.assign_buffer(&op_buf);

    man1.copy_from_image(&x);
    man2.copy_from_image(&x);

    //ColorSeeker seeker(&ip_buf);

    /*for (int m=0; m<=vec.ysize-1; m++)
    {
        for (int n=0; n<=vec.xsize-1; n++)
        {
            cout<<vec.matrix[m][n]<<" ";
        }

        cout<<endl;
    }*/

    //seeker.build_bintable(0,15);
    //seeker.scan_buffer().scan_buffer();
    //seeker.scan_buffer();
    //god.convert_to_greyscale(&ip_buf,&op_buf);
    //god.channel_adjust(&ip_buf,&op_buf,30,0,0);
    //god.contrast_stretch(&ip_buf,&op_buf,RED,1,atof(argv[1]),1);
    //god.contrast_stretch(&op_buf,&ip_buf,GREEN,1,atof(argv[1]),1);
    //god.contrast_stretch(&ip_buf,&op_buf,BLUE,1,atof(argv[1]),1);
    //god.histogram_equalise(&ip_buf,&op_buf,BLUE);
    //god.histogram_equalise(&op_buf,&ip_buf,RED);
    //god.histogram_equalise(&ip_buf,&op_buf,GREEN);
    //god.range_compress(&ip_buf,&op_buf,1.6);
    //etor.Sobel(&op_buf,&ip_buf,atoi(argv[1]));
    //god.convert_to_greyscale(&ip_buf,&op_buf);
    //god.convert_to_negative(&ip_buf,&op_buf);
    //op.assign_buffer_ptrs(&ip_buf,&op_buf);
    //op.convolve();
    //det.detect_edge(&op_buf,&ip_buf);
    //god.fast_unsharp_mask(&ip_buf,&op_buf,3);
    skel.skeletonise(&ip_buf,&op_buf);

    //det.detect_edge(&op_buf,&ip_buf);
    //det.clean(&ip_buf,&op_buf);

    //BufferConvertor::RGB_to_HSL_buffer(&check,&ip_buf);
    //BufferConvertor::RGB_to_HSL_buffer(&checkdash,&op_buf);

    //blank_variances(check,atof(argv[2]),atoi(argv[1]));
    /*long total=0;
    long total2=0;
    vector<InterestArea> ltbl;
    vector<InterestArea> rtbl;

    total=build_scanline_map(check,atof(argv[1]),ltbl);
    total2=build_scanline_map(checkdash,atof(argv[1]),rtbl);

    stereo_correlate(ltbl,rtbl);*/

    //BufferConvertor::HSL_to_RGB_buffer(&ip_buf,&check);
    //BufferConvertor::HSL_to_RGB_buffer(&op_buf,&checkdash);

    //cout<<"Total number of interest areas="<<total<<" "<<total2<<endl;

    //god.dilate(&ip_buf,&op_buf);
    //god.dilate(&op_buf,&ip_buf);
    //god.dilate(&ip_buf,&op_buf);
    //god.erode(&ip_buf,&op_buf);
    //god.erode(&op_buf,&ip_buf);


    /*
    god.dilate(&ip_buf,&op_buf);

    ShapeSampler sam;

    sam.sample(&op_buf,rad1,25,161,162);
    sam.sample(&op_buf,rad2,25,40,39);

    seq.normalise(rad1,25);
    seq.normalise(rad2,25);

    cout<<"Result="<<seq.match(rad1,rad2,25);
    cin.get();

    for (int i=0; i<=24; i++)
    {
        cout<<rad1[i]<<" "<<rad2[i]<<endl;
    }

    cout<<endl;
    */

    //cout<<"\nAngle is "<<regression(&ip_buf);

    //god.channel_adjust(&ip_buf,&op_buf,-255,0,-255);

    //god.erode(&ip_buf,&op_buf); //,0,100,399,200);

    //god.convert_to_negative(&ip_buf,&op_buf);

    man2.copy_to_image(&x);
    //man2.copy_to_image(&y);//,0,0,199,99,0,100);

    x.byte_reader.writer.close();
    x.byte_reader.reader.close();

    //y.byte_reader.writer.close();
    //y.byte_reader.reader.close();

    cout<<"\nProcessing complete...\n";

    cin.get();

    return 0;
}


