#ifndef KERNEL_MATRIX_H
#define KERNEL_MATRIX_H

#include "BitmapStreamer.h"
#include "ColorSpaces.h"
#include "Buffer.h"
//#include "Gollum.h"

namespace Comrade {
	namespace IrisXT {
	
using namespace IrisFoundation;

struct KernelMatrix
{
    int xsize,ysize;
    double** matrix;

    KernelMatrix(int r,int c);
    void set_values(double* arr);
    ~KernelMatrix();
};

class KernelOperator
{
protected:  KernelMatrix* rgb_kernel;
            BitmapStreamer* reader;
            double factor;
            int xsz,ysz;

public:     RGB** ip_buffer;
            RGB** op_buffer;

            KernelOperator();

            // Deprecated, do NOT use this function!!
            //void set_bounds(int x,int y);

            void set_bounds(BitmapStreamer* bmp_reader);
            inline void set_factor(int fac);
            inline void assign_buffer_ptrs(Buffer<RGB>* ip,Buffer<RGB>* op);
            inline void assign_kernel(KernelMatrix* mat);
            void convolve(int x1,int y1,int x2,int y2);
            void convolve();

            ~KernelOperator();
};

inline void KernelOperator::set_factor(int fac)
{
    factor=fac;
}

inline void KernelOperator::assign_buffer_ptrs(Buffer<RGB>* ip,Buffer<RGB>* op)
{
    ip_buffer=ip->buffer_ptr;
    op_buffer=op->buffer_ptr;

    xsz=ip->maxx;
    ysz=ip->maxy;
}

inline void KernelOperator::assign_kernel(KernelMatrix* mat)
{
    rgb_kernel=mat;
}

}
}

#endif

