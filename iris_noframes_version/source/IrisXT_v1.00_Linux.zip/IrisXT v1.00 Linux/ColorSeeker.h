#ifndef COLOR_SEEKER_H
#define COLOR_SEEKER_H

#include "BufferConvertor.h"

namespace Comrade {
	namespace IrisXT {
	
using namespace Comrade::IrisFoundation;

class ColorSeeker
{
protected:  Buffer<int>* current_buffer;
            Buffer<int>* future_buffer;
            Buffer<HSLstruct>* buffer_HSL;

public:     ColorSeeker(Buffer<RGB>* buffer);

            int get_count(double hue,double tolerance,
                          int x1,int y1,int x2,int y2);
            int get_count(double hue,double tolerance);
            
            void build_bintable(double hue,double tolerance);

            ColorSeeker& scan_buffer(int x1,int y1,
                                     int x2,int y2);
            ColorSeeker& scan_buffer();

            ~ColorSeeker();
};

}
}

#endif


