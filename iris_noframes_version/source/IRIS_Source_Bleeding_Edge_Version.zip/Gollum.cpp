#include "Gollum.h"

Gollum::Gollum(char* name)
{
    strncpy(filename,name,19);
}

void Gollum::label(char* dat)
{
    strncpy(session_details,dat,149);
}

void Gollum::end()
{
    //writer.open(filename,ios::out|ios::app);
}

void Gollum::start_track(char* desc)
{
    start_time=clock();

    RecordUnit temp;
    temp.description=string(desc);
    temp.time_count=start_time;
    temp.type=TIME_COUNTER_START;
    is_logging=true;

    storage.push_back(temp);
}

void Gollum::end_track()
{
    if (is_logging==true)
    {
        clock_t cur=clock();

        RecordUnit temp;
        temp.description="Time track ends at:";
        is_logging=false;
        temp.time_count=cur-start_time;
        temp.type=TIME_COUNTER_END;

        storage.push_back(temp);
    }
}

void Gollum::log_now(char* desc)
{
    RecordUnit temp;
    temp.description=string(desc);
    temp.time_count=clock();
    temp.type=CHECKPOINT;
    is_logging=false;

    storage.push_back(temp);
}

Gollum::~Gollum()
{
    cout<<"Session description? ";
    cin.getline(session_details,149);

    writer.open(filename,ios::out|ios::app);

    writer<<"------------------------------------\n";
    writer<<"START OF SESSION\n";
    writer<<"------------------------------------\n\n";

    writer<<"Session description:"<<session_details<<endl<<endl;

    for (int i=0; i<=storage.size()-1; i++)
    {
        if (storage[i].type==CHECKPOINT)
        {
            writer<<"Checkpoint\n----------\n";
            writer<<storage[i].description<<endl;
            writer<<"Occurred at system time "<<storage[i].time_count;
            writer<<"**\n\n";
        }

        if (storage[i].type==TIME_COUNTER_START)
        {
            writer<<"Time tracking started\n------------------\n";
            writer<<storage[i].description<<endl;
            writer<<"Occurred at system time "<<storage[i].time_count;
            writer<<"**\n\n";
        }

        if (storage[i].type==TIME_COUNTER_END)
        {
            writer<<"Stopped tracking\n------------------\n";
            writer<<storage[i].description<<endl;
            writer<<"Event(s) lasted for (system time units) "<<storage[i].time_count;
            writer<<"\n**\n";
        }
    }

    writer<<"------------------------------------\n";
    writer<<"END OF SESSION\n";
    writer<<"------------------------------------\n\n";

    writer.close();
}
