#include <iostream>
#include "WorldSpace.h"

using namespace Comrade::Iris3D;
using namespace std;

int main()
{
	WorldSpace one;
	
	cin.get();
	return 0;
}


