#include "ColorSeeker.h"

Comrade::IrisXT::ColorSeeker::ColorSeeker(Buffer<RGB>* buffer)
{
    cout<<"Setting up buffers for new ColorSeeker...\n";

    current_buffer=new Buffer<int>(buffer->maxx,buffer->maxy);
    future_buffer=new Buffer<int>(buffer->maxx,buffer->maxy);
    buffer_HSL=new Buffer<HSLstruct>(buffer->maxx,buffer->maxy);

    for (int y=0; y<=future_buffer->maxy-1; y++)
    {
        for (int x=0; x<=future_buffer->maxx-1; x++)
        {
            future_buffer->at(x,y)=0;
        }
    }

    BufferConvertor::RGB_to_HSL_buffer(buffer_HSL,buffer);
}

void Comrade::IrisXT::ColorSeeker::build_bintable(double hue,double tolerance)
{
    cout<<"Wait. Building binary table...\n";

    for (int y=0; y<=buffer_HSL->maxy-1; y++)
    {
        for (int x=0; x<=buffer_HSL->maxx-1; x++)
        {
            double error=fabs((buffer_HSL->at(x,y)).hue-hue);

            current_buffer->at(x,y)=(error>tolerance)?0:1;
        }
    }
}

int Comrade::IrisXT::ColorSeeker::get_count(double hue,double tolerance)
{
    int sum=get_count(hue,tolerance,0,0,
                      buffer_HSL->maxx-1,
                      buffer_HSL->maxy-1);

    return sum;
}

int Comrade::IrisXT::ColorSeeker::get_count(double hue,double tolerance,
                           int x1,int y1,int x2,int y2)
{
    int sum=0;

    for (int y=y1; y<=y2; y++)
    {
        for (int x=x1; x<=x2; x++)
        {
            double error=fabs((buffer_HSL->at(x,y)).hue-hue);

            sum+=(error>tolerance)?0:1;
        }
    }

    return sum;
}

Comrade::IrisXT::ColorSeeker& Comrade::IrisXT::ColorSeeker::scan_buffer()
{
    scan_buffer(0,0,current_buffer->maxx-1,
                    current_buffer->maxy-1);
    return (*this);
}

Comrade::IrisXT::ColorSeeker& Comrade::IrisXT::ColorSeeker::scan_buffer(int x1,int y1,
                                      int x2,int y2)
{
    for (int y=y1; y<=y2; y++)
    {
        for (int x=x1; x<=x2; x++)
        {
            if (current_buffer->at(x,y)!=0)
            {
                for (int yy=y-1; yy<=y+1; yy++)
                {
                    for (int xx=x-1; xx<=x+1; xx++)
                    {
                        if (xx==x && yy==y)
                        {
                            continue;
                        }

                        if (xx>=0 && xx<=current_buffer->maxx-1 &&
                            yy>=0 && yy<=current_buffer->maxy-1)
                        {
                            future_buffer->at(x,y)+=
                            current_buffer->at(xx,yy);
                        }
                    }
                }
            }
        }
    }

    current_buffer->copy_from(future_buffer);
    return (*this);
}

Comrade::IrisXT::ColorSeeker::~ColorSeeker()
{
    delete current_buffer;
    delete future_buffer;
    delete buffer_HSL;
}


