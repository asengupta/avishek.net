#include <iostream>
#include "FrontEnd.h"
#include "CommandFunctionList.h"
#include "IrisEnv.h"
#include "WorldSpace.h"
#include "SOM_Trainer.h"

//#define VIRTUAL_MACHINE_DEMO
//#define HOUGH_DEMO
//#define STEREO_DEMO
//#define SPACE_CARVE_DEMO
//#define QT_SEG_STEREO_DEMO
#define HOUGH_SHAPE_DEMO
//#define EDGE_DETECTOR_DEMO

extern Comrade::IrisRuntime::IrisEnvironment* iris_vm;
extern Comrade::IrisFoundation::Buffer<Comrade::IrisFoundation::RGB>* bufptr;
extern bool complete;
extern long carved;

using namespace std;
using namespace Comrade::IrisFoundation;
using namespace Comrade::IrisXT;
using namespace Comrade::Iris3D;
using namespace Comrade::IrisRuntime;
using namespace Comrade::Osiris;

bool belongs(Rectangle rect,Coordinate coord);

#ifdef VIRTUAL_MACHINE_DEMO
int main()
{
   cout<<"Starting now...";
   
   BitmapStreamer left,right,dmap;
   left.byte_reader.reader.open("Left.bmp",ios::in|ios::binary|ios::nocreate);
   left.byte_reader.writer.open("Left.bmp",ios::out|ios::binary|ios::nocreate);

   //right.byte_reader.reader.open("Right.bmp",ios::in|ios::binary|ios::nocreate);
   //right.byte_reader.writer.open("Right.bmp",ios::out|ios::binary|ios::nocreate);

   //dmap.byte_reader.reader.open("Blank.bmp",ios::in|ios::binary|ios::nocreate);
   //dmap.byte_reader.writer.open("Blank.bmp",ios::out|ios::binary|ios::nocreate);

   if (left.byte_reader.reader.is_open()==false ||
       right.byte_reader.reader.is_open()==false ||
       dmap.byte_reader.reader.is_open()==false)
   {
        cout<<"Files could not be opened...\n";

        cin.get();
        return 0;
   }

   Buffer<RGB> l(&left),r(&right),d(&dmap);

   RGB_BufferManager manl,manr,mand;
   manl.assign_buffer(&l);
   //manr.assign_buffer(&r);
   //mand.assign_buffer(&d);

   manl.copy_from_image(&left);
   //manr.copy_from_image(&right);

   cout<<"Finished copying to buffer...\n";
   
   cin.get();
   return 0;
   
   //iris_vm=new IrisEnvironment;
    
    //iris_vm->activate();
    
    //delete iris_vm;
    
    DepthmapBuilder bldr;
    bldr.set_stepsize(1);

    bldr.build_depthmap(&l,&r,&d);

    mand.copy_to_image(&dmap);

    left.byte_reader.reader.close();
    left.byte_reader.writer.close();

    right.byte_reader.reader.close();
    right.byte_reader.writer.close();

    dmap.byte_reader.reader.close();
    dmap.byte_reader.writer.close();

    cin.get();
    return 0;
}
#endif

#ifdef HOUGH_DEMO
int main()
{
   cout<<"Starting now...";
   StraightLineDetector detor;
   long int** arr;
   
   EdgeDetectorManager eddie;
   BitmapStreamer left,right;
   
   RGB white={255,255,255};
   RGB black={0,0,0};
   
   right.byte_reader.reader.open("Blank.bmp",ios::in|ios::binary|ios::nocreate);
   right.byte_reader.writer.open("Blank.bmp",ios::out|ios::binary|ios::nocreate);
   
   left.byte_reader.reader.open("Avishek.bmp",ios::in|ios::binary|ios::nocreate);
   left.byte_reader.writer.open("Avishek.bmp",ios::out|ios::binary|ios::nocreate);
   
   Buffer<RGB> buf(&left),op_buf(&left),final(&right);
   RGB_BufferManager man,opman;
   opman.assign_buffer(&final);
   man.assign_buffer(&buf);
   man.copy_from_image(&left);
   eddie.Canny(&buf,&op_buf,.25);
   
   detor.transform(&op_buf);
   arr=detor.return_array();
   
   for (int y=0; y<=buf.maxy-1; y++)
   {
   		for (int x=0; x<=buf.maxx-1; x++)
   		{
   			final.at(x,y)=black;
   		}
   }   
   
   for (int y=0; y<=detor.return_rows()-1; y++)
   {
   		for (int x=0; x<=detor.return_cols()-1; x++)
      	{
            final.at(x,y).red=0;
         	final.at(x,y).green=arr[y][x];
         	final.at(x,y).blue=0;
                          	
            if (arr[y][x]>=150)
            {
            	for (int xx=0; xx<=buf.maxx-1; xx++)
            	{
	            	int coordy=static_cast<int>((y-xx*cos(deg_to_rad(x)))/sin(deg_to_rad(x)));
	            	
	            	if (op_buf.at(xx,coordy).red==255 &&
				     	op_buf.at(xx,coordy).green==255 &&
				     	op_buf.at(xx,coordy).blue==255)
				    { 
              			buf.at(xx,coordy)=white;
          			}
            	}
            	
            	for (int yy=0; yy<=buf.maxy-1; yy++)
            	{
	            	int coordx=static_cast<int>((y-yy*sin(deg_to_rad(x)))/cos(deg_to_rad(x)));
	            	
	            	if (op_buf.at(coordx,yy).red==255 &&
				     	op_buf.at(coordx,yy).green==255 &&
				     	op_buf.at(coordx,yy).blue==255)
				    { 
              			buf.at(coordx,yy)=white;
          			}
            	}
           	}
      	}
   }
   
   opman.copy_to_image(&right);
   //END: opman.copy_to_image(&right);
   
   left.byte_reader.reader.close();
   left.byte_reader.writer.close();

   right.byte_reader.reader.close();
   right.byte_reader.writer.close();

   cout<<"Done...\n";
   
   
   cin.get();
   return 0;
}
   
#endif

#ifdef STEREO_DEMO
int main()
{
   //return 0;
   cout<<"Starting now...";

   BitmapStreamer left,right,dmap;
   left.byte_reader.reader.open("Right.bmp",ios::in|ios::binary|ios::nocreate);
   left.byte_reader.writer.open("Right.bmp",ios::out|ios::binary|ios::nocreate);

   right.byte_reader.reader.open("Left.bmp",ios::in|ios::binary|ios::nocreate);
   right.byte_reader.writer.open("Left.bmp",ios::out|ios::binary|ios::nocreate);

   dmap.byte_reader.reader.open("Blank.bmp",ios::in|ios::binary|ios::nocreate);
   dmap.byte_reader.writer.open("Blank.bmp",ios::out|ios::binary|ios::nocreate);

   if (left.byte_reader.reader.is_open()==false ||
       right.byte_reader.reader.is_open()==false ||
       dmap.byte_reader.reader.is_open()==false)
   {
        cout<<"Files could not be opened...\n";

        cin.get();
        return 0;
   }

   Buffer<RGB> l(&left),r(&right),d(&dmap);

   RGB_BufferManager manl,manr,mand;
   manl.assign_buffer(&l);
   manr.assign_buffer(&r);
   mand.assign_buffer(&d);

   manl.copy_from_image(&left);
   manr.copy_from_image(&right);

   cout<<"Finished copying to buffer...\n";
   
   //iris_vm=new IrisEnvironment;
    
    //iris_vm->activate();
    
    //delete iris_vm;
    
    DepthmapBuilder bldr;
    bldr.set_stepsize(1);

    bldr.build_depthmap(&l,&r,&d);

    mand.copy_to_image(&dmap);

    left.byte_reader.reader.close();
    left.byte_reader.writer.close();

    right.byte_reader.reader.close();
    right.byte_reader.writer.close();

    dmap.byte_reader.reader.close();
    dmap.byte_reader.writer.close();

    cout<<"Done...\n";
    
    cin.get();
    return 0;
}

#endif

#ifdef SPACE_CARVE_DEMO
int main()
{    
    cout<<"Let's first check where the voxels project to...\n";

	int numpics=2;

    BitmapStreamer x;
    BitmapStreamer test;

        // Test code starts
    /*
        test.byte_reader.reader.open("K:\\Datasets\\GargoyleX.bmp",ios::in|ios::binary);
        test.byte_reader.writer.open("K:\\Datasets\\GargoyleX.bmp",ios::in|ios::out|ios::binary);

        if (test.byte_reader.reader.is_open()==true)
        {
            cout<<"File could be opened...";
        }

        else
        {
            cout<<"File could not be opened...\n";
            cin.get();
            return 0;
        }
        //cin.get();
    */
        // Test code ends

    Buffer<HSLstruct> vec[2];
    Buffer<bool> marked[2];

    Buffer<RGB> somergb(400,320);
    Buffer<HSLstruct> somehsl(400,320);

    //vector< Buffer<HSLstruct> > vec(numpics);//,Buffer<HSLstruct>(GARGOYLE_X,GARGOYLE_Y));
    vector<Sensor> svec;
    //vector< Buffer<bool> > marked(numpics);//,Buffer<bool>(GARGOYLE_X,GARGOYLE_Y));

    //cout<<"READY";
    //cin.get();
    // Init marked array

    for (int i=0; i<=numpics-1; i++)
    {
        for (int yy=0; yy<=GARGOYLE_Y-1; yy++)
        {
            for (int xx=0; xx<=GARGOYLE_X-1; xx++)
            {
                marked[i].at(xx,yy)=false;
            }
        }
    }

    //cout<<"Gih!";
    //cin.get();

    WorldSpace one;
    one.fill_coordinates(30,30,30);
    Voxel vox1=one.world[10][10][0];
    Voxel vox2=one.world[0][0][0];
    Voxel vox3=one.world[0][20][0];
    Voxel vox4=one.world[20][0][0];
    Voxel vox5=one.world[20][20][0];
    
    //cout<<"Almost";
    //cin.get();

    RGB_BufferManager bman;

    // Test part starts
    //Buffer<RGB> testrgb(&test);
    //bman.assign_buffer(&testrgb);
    //bman.copy_from_image(&test);
    //bufptr=&testrgb;
    // Test part ends

    x.byte_reader.reader.open("Left",ios::in|ios::binary);
    x.byte_reader.writer.open("Left",ios::in|ios::out|ios::binary);

    if (x.byte_reader.reader.is_open()==true)
    {
        cout<<"File could be opened...";
    }

    //Buffer<RGB> somergb(&x);
    //Buffer<HSLstruct> somehsl(&x);

    bman.assign_buffer(&somergb);
    bman.copy_from_image(&x);
    BufferConvertor::RGB_to_HSL_buffer(&somehsl,&somergb);

    vec[0].copy_from(&somehsl);

    x.byte_reader.writer.close();
    x.byte_reader.reader.close();
    
	x.byte_reader.reader.open("Right",ios::in|ios::binary);
    x.byte_reader.writer.open("Right",ios::in|ios::out|ios::binary);

    if (x.byte_reader.reader.is_open()==true)
    {
        cout<<"File could be opened...";
    }

    //Buffer<RGB> somergb(&x);
    //Buffer<HSLstruct> somehsl(&x);

    bman.assign_buffer(&somergb);
    bman.copy_from_image(&x);
    BufferConvertor::RGB_to_HSL_buffer(&somehsl,&somergb);

    vec[0].copy_from(&somehsl);

    x.byte_reader.writer.close();
    x.byte_reader.reader.close();
    
 	//double radius=50000; // 1000 is nice
    int cnt=0;

    //for (double ang=0; ang<=359; ang+=360./numpics,cnt++)
    //{
        //double xx=radius*cos(deg_to_rad(ang));
        //double yy=radius*sin(deg_to_rad(ang));
		
  		double x1=5000,y1=30;
		double x2=x1,y2=-y1;
		
        Coordinate oc1(x1,y1,0);
        Coordinate oc2(x2,y2,0);
        
        //Coordinate tg(0,0,0);

        double A1=0-x1;
        double B1=0-y1;
        double C1=0;
        
        double A2=0-x2;
        double B2=0-y2;
        double C2=0;
        
		Coordinate fc1(x1+A1*.0095,y1+B1*.0095,0); //.3 is OK
		Coordinate fc2(x2+A2*.0095,y2+B2*.0095,0); //.3 is OK

        Sensor cx,cy;
        cy.set(oc2,fc2,0.825,0.55);//6.6.4.4
        cy.img_buffer_ptr=&vec[1];
        cy.flag_buffer_ptr=&marked[1];

        cx.set(oc1,fc1,0.825,0.55);//6.6.4.4
        cx.img_buffer_ptr=&vec[0];
        cx.flag_buffer_ptr=&marked[0];

		cout<<"Focal plane at ("<<fc1.get_x()<<","<<fc1.get_y()<<",0)\n";
        cout<<"Focal plane at ("<<fc2.get_x()<<","<<fc2.get_y()<<",0)\n";
        
        svec.push_back(cx);
    	svec.push_back(cy);

	/*
    Coordinate gih1(vox1.x,vox1.y,vox1.z);
    Coordinate gih2(vox2.x,vox2.y,vox2.z);
    Coordinate gih3(vox3.x,vox3.y,vox3.z);
    Coordinate gih4(vox4.x,vox4.y,vox4.z);
    Coordinate gih5(vox5.x,vox5.y,vox5.z);

    gih1=VoxelWorker::intersection_of(gih1,svec[0]);
    gih2=VoxelWorker::intersection_of(gih2,svec[0]);
    gih3=VoxelWorker::intersection_of(gih3,svec[0]);
    gih4=VoxelWorker::intersection_of(gih4,svec[0]);
    gih5=VoxelWorker::intersection_of(gih5,svec[0]);
    
    cout<<gih1.get_x()<<" "<<gih1.get_y()<<" "<<gih1.get_z()<<endl;
    cout<<gih2.get_x()<<" "<<gih2.get_y()<<" "<<gih2.get_z()<<endl;
    cout<<gih3.get_x()<<" "<<gih3.get_y()<<" "<<gih3.get_z()<<endl;
    cout<<gih4.get_x()<<" "<<gih4.get_y()<<" "<<gih4.get_z()<<endl;
    cout<<gih5.get_x()<<" "<<gih5.get_y()<<" "<<gih5.get_z()<<endl;
    */

    cout<<"Ready to carve...press [Ctrl-Brk] to abort, any other key to continue\n";
    cin.get();

    //for(int i=0; i<=0; i++)
    //do
    //{
        carved=0;
        complete=true;

        RGB green={0,255,0};

        // Test part starts
        /*
        Coordinate box[8];
        int op[2][2];

        int ex=0,ey=0;

        for (int i=0; i<=WORLD_Z-1; i++)
        {
            for (int j=0; j<=WORLD_Y-1; j++)
            {
                for (int k=0; k<=0; k++)
                {
                    VoxelWorker::bounded_intersection_of(one.world[i][j][k],svec[0],box);
                    VoxelWorker::find_rectangle(op,box);

                    //cout<<"("<<op[0][0]<<","<<op[0][1]<<")-(";
                    //cout<<op[0][1]<<","<<op[1][1]<<")"<<endl;

                    if (op[0][0]==op[1][0])
                    {
                        //cout<<":-("<<endl;
                        ex++;
                    }

                    if (op[0][1]==op[1][1])
                    {
                        //cout<<":-("<<endl;
                    ey++;
                    }

                    for (int u=op[0][0]; u<=op[1][0]; u++)
                    {
                        testrgb.at(GARGOYLE_X/2+u,GARGOYLE_Y/2-op[0][1])=green;
                        testrgb.at(GARGOYLE_X/2+u,GARGOYLE_Y/2-op[1][1])=green;
                    }

                    for (int u=op[0][1]; u<=op[1][1]; u++)
                    {
                        testrgb.at(GARGOYLE_X/2+op[0][0],GARGOYLE_Y/2-u)=green;
                        testrgb.at(GARGOYLE_X/2+op[1][0],GARGOYLE_Y/2-u)=green;
                    }
                }
            }
        }

        cout<<"ex="<<ex<<" "<<"ey="<<ey;

        */
// Test part ends

        x_space_carve_inc(svec,one);
        //x_space_carve_dec(svec,one);

        //y_space_carve_inc(svec,one);
        //y_space_carve_dec(svec,one);

        cout<<carved<<" pixels carved.\n";
    //}
    //while(complete==false);
    
    //ofstream bound("Bound.txt");
    cout<<"Stand by for voxel render procedure...\n";

    // Voxel rendering

    x.byte_reader.reader.open("Blank.bmp",ios::nocreate|ios::in|ios::binary);
    x.byte_reader.writer.open("Blank.bmp",ios::nocreate|ios::out|ios::binary);

    if (x.byte_reader.reader.is_open()==true)
    {
        cout<<"Output file could be opened...\n";
    }

    else
    {
        cout<<"Output file could not be opened...\n";
    }

    Buffer<RGB> buf(&x);
    RGB_BufferManager man1;
    man1.assign_buffer(&buf);
    man1.copy_from_image(&x);

    int g=0,h=0;

    RGB white={255,255,255};
    //RGB green={0,255,0};
    RGB black={0,0,0};

    cout<<"Clears buffers...\n";
    for (int yy=0; yy<=599; yy++)
    {
        for (int xx=0; xx<=799; xx++)
        {
            buf.at(xx,yy)=black;
        }
    }

    cout<<"Before drawing slices...\n";
    for (int yy=0; yy<=WORLD_Y-1; yy++)
    {
        //cout<<"Drawing slice "<<yy<<endl;

        for (int zz=0; zz<=WORLD_Z-1; zz++)
        {
            for (int xx=0; xx<=WORLD_X-1; xx++)
            {
                if (one.world[zz][yy][xx].carved==true)
                {
                    RGB black={0,0,0};
                    buf.at(xx+g*(WORLD_X-1),zz+h*(WORLD_Z-1))=black;
                    continue;
                }

                else
                {
                    //cout<<"Coloring...\n";

                    HSLstruct col=one.world[zz][yy][xx].color;
                    RGB color=ColorSpaceConvertor::HSL_to_uRGB(col);

                    buf.at(xx+g*(WORLD_X-1),zz+h*(WORLD_Z-1))=color;
                }
            }
        }

        g++;

        if (g>800/WORLD_X)
        {
            h++;
            g=0;
        }
    }

    cout<<"Before drawing grid...\n";
    // Draw grid
    for (int sy=0; sy<=599; sy+=60)
    {
        for (int sx=0; sx<=799; sx++)
        {
            buf.at(sx,sy)=green;
        }
    }

    for (int sx=0; sx<=799; sx+=60)
    {
        for (int sy=0; sy<=599; sy++)
        {
            buf.at(sx,sy)=green;
        }
    }
    // End drawing grid

    man1.copy_to_image(&x);

    x.byte_reader.reader.close();
    x.byte_reader.writer.close();
    //bound.close();

    cout<<"Tests completed...\n";

    // Test code starts
    //bman.assign_buffer(&testrgb);
    //bman.copy_to_image(&test);

    //test.byte_reader.reader.close();
    //test.byte_reader.writer.close();
    // Test code ends
    
    cin.get();
    return 0;
}

#endif

#ifdef QT_SEG_STEREO_DEMO
int main()
{
 	BitmapStreamer left,right,dmap;
   left.byte_reader.reader.open("maxleft.bmp",ios::in|ios::binary|ios::nocreate);
   left.byte_reader.writer.open("maxleft.bmp",ios::out|ios::binary|ios::nocreate);

   right.byte_reader.reader.open("maxright.bmp",ios::in|ios::binary|ios::nocreate);
   right.byte_reader.writer.open("maxright.bmp",ios::out|ios::binary|ios::nocreate);

   dmap.byte_reader.reader.open("Blank.bmp",ios::in|ios::binary|ios::nocreate);
   dmap.byte_reader.writer.open("Blank.bmp",ios::out|ios::binary|ios::nocreate);

   if (left.byte_reader.reader.is_open()==false ||
       right.byte_reader.reader.is_open()==false ||
       dmap.byte_reader.reader.is_open()==false)
   {
        cout<<"Files could not be opened...\n";

        cin.get();
        return 0;
   }

   Buffer<RGB> l(&left),r(&right),d(&dmap);

   RGB_BufferManager manl,manr,mand;
   manl.assign_buffer(&l);
   manr.assign_buffer(&r);
   mand.assign_buffer(&d);

   manl.copy_from_image(&left);
   manr.copy_from_image(&right);

   cout<<"Finished copying to buffer...\n";
   
	RGB black={0,0,0};
    
    Rectangle start={0,0,l.maxx,l.maxy,black};

    Tree<Rectangle,Coordinate> oak(start);
    oak.set_subsethood_fn(belongs);

    QuadtreeSegmenter seger;
    seger.minx=seger.miny=16;
    seger.threshold=40;
	
    seger.build_quadtree(&oak,&l);
    //seger.draw_quadtree(&oak,&d);

    DepthmapBuilder bldr;
    
    //bldr.uncertainty_color.red=0;
    
    //bldr.set_stepsize(2);
	bldr.set_qualify_thresh(5);
 	//bldr.set_y_offset(2);
  	bldr.set_x_extent(40);
  	bldr.set_left_right_tolerance(100);
  	bldr.set_max_allowed_diff(100);
   	//bldr.set_y_offset(3);
	
    //EpipolarRectifier recter;
    
    bldr.build_depthmap(&l,&r,&d,&oak);

    mand.copy_to_image(&dmap);

    left.byte_reader.reader.close();
    left.byte_reader.writer.close();

    right.byte_reader.reader.close();
    right.byte_reader.writer.close();

    dmap.byte_reader.reader.close();
    dmap.byte_reader.writer.close();

    cout<<"Done...\n";
	cin.get();
	return 0;
}

#endif

#ifdef HOUGH_SHAPE_DEMO

int main()
{
	cout<<"Starting Hough shape detection demo...\n";

	BitmapStreamer one,two,three,four;

    one.byte_reader.reader.open("circle.bmp",ios::in|ios::binary|ios::nocreate);
   	one.byte_reader.writer.open("circle.bmp",ios::out|ios::binary|ios::nocreate);

	two.byte_reader.reader.open("blank.bmp",ios::in|ios::binary|ios::nocreate);
   	two.byte_reader.writer.open("blank.bmp",ios::out|ios::binary|ios::nocreate);

 	three.byte_reader.reader.open("some.bmp",ios::in|ios::binary|ios::nocreate);
   	three.byte_reader.writer.open("some.bmp",ios::out|ios::binary|ios::nocreate);

  	four.byte_reader.reader.open("edge.bmp",ios::in|ios::binary|ios::nocreate);
   	four.byte_reader.writer.open("edge.bmp",ios::out|ios::binary|ios::nocreate);

   	Buffer<RGB> b1(&one),b2(&two),b3(&three),b4(&four);
 	
  	EdgeDetectorManager eddie;
  	
   	RGB_BufferManager man1,man2,man3,man4;
	man1.assign_buffer(&b1);
	man2.assign_buffer(&b2);
	man3.assign_buffer(&b3);
	man4.assign_buffer(&b4);

	man1.copy_from_image(&one);
	man3.copy_from_image(&three);
	eddie.Canny(&b3,&b4,.002);

  	BasicShapeDetector detor;
	detor.build_shape_table(&b1,109,97,40);
	
	//cout<<detor.shape_table.size()<<endl;

  	for (unsigned int i=0; i<=detor.shape_table.size()-1; ++i)
	{
		cout<<detor.shape_table[i]<<endl;
	}

 	detor.change_sz=0;
  	
    RGB black={0,0,0};

    man2.fill(black);
    detor.transform(&b3);

	Buffer<int>* ptr=detor.return_array();
	
 	for (int yy=0; yy<=ptr->maxy-1; ++yy)
	{
		for (int xx=0; xx<=ptr->maxx-1; ++xx)
		{
   			double inter=20*ptr->at(xx,yy);
			inter=(inter>255)?255:inter;
			
            b2.at(xx,yy).green=static_cast<unsigned char>(inter);
   			b2.at(xx,yy).red=b2.at(xx,yy).blue=0;
 		}
	}
	
	man2.copy_to_image(&two);
	man4.copy_to_image(&four);

 	one.byte_reader.reader.close();
	one.byte_reader.writer.close();

    two.byte_reader.reader.close();
    two.byte_reader.writer.close();

  	three.byte_reader.reader.close();
	three.byte_reader.writer.close();

 	four.byte_reader.reader.close();
	four.byte_reader.writer.close();

   	cout<<"Processing done.\n";
	cin.get();
	return 0;
}

#endif

#ifdef EDGE_DETECTOR_DEMO

int main()
{
	BitmapStreamer ip,op;
	
 	ip.byte_reader.reader.open("circle.bmp",ios::in|ios::binary|ios::nocreate);
   	ip.byte_reader.writer.open("circle.bmp",ios::out|ios::binary|ios::nocreate);

	op.byte_reader.reader.open("blank.bmp",ios::in|ios::binary|ios::nocreate);
   	op.byte_reader.writer.open("blank.bmp",ios::out|ios::binary|ios::nocreate);

	EdgeDetectorManager eddie;
	
	Buffer<RGB> ip_buf(&ip),op_buf(&op);
   	RGB_BufferManager ipman,opman;
   	
    ipman.assign_buffer(&ip_buf);
    opman.assign_buffer(&op_buf);
   	
    ipman.copy_from_image(&ip);
   	eddie.Canny(&ip_buf,&op_buf,.25);
   	
   	opman.copy_to_image(&op);
   	
   	ip.byte_reader.reader.close();
   	ip.byte_reader.writer.close();
   	
	op.byte_reader.reader.close();
   	op.byte_reader.writer.close();

	cout<<"Processing finished.\n";
 	cin.get();
	return 0;
}

#endif


bool belongs(Rectangle rect,Coordinate coord)
{
    if (coord.get_x()>=rect.x1 &&
        coord.get_y()>=rect.y1 &&
        coord.get_x()<=rect.x2 &&
        coord.get_y()<=rect.y2)
    {
        return true;
    }

    else
    {
        return false;
    }
}


