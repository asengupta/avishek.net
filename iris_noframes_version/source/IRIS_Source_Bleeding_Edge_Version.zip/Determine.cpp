#include "IrisTests.h"

int main()
{
    interactive_intersector();

    cin.get();
    return 0;
}


