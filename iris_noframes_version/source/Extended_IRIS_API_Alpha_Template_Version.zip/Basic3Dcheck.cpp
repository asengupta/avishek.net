#include <cstring>
#include "BufferConvertor.h"
#include "ModelBuilder.h"

using namespace Comrade::IrisFoundation;
//using namespace Comrade::IrisXT;
using namespace Comrade::Iris3D;

extern Buffer<RGB>* bufptr;
extern bool complete;
extern long carved;

int main(int argv,char* argc[])
{
    cout<<"Let's first check where the voxels project to...\n";

	int numpics=16;

    BitmapStreamer x;
    BitmapStreamer test;

        // Test code starts
    /*
        test.byte_reader.reader.open("K:\\Datasets\\GargoyleX.bmp",ios::in|ios::binary);
        test.byte_reader.writer.open("K:\\Datasets\\GargoyleX.bmp",ios::in|ios::out|ios::binary);

        if (test.byte_reader.reader.is_open()==true)
        {
            cout<<"File could be opened...";
        }

        else
        {
            cout<<"File could not be opened...\n";
            cin.get();
            return 0;
        }
        //cin.get();
    */
        // Test code ends

    Buffer<HSLstruct> vec[16];
    Buffer<bool> marked[16];

    Buffer<RGB> somergb(320,240);
    Buffer<HSLstruct> somehsl(320,240);

    //vector< Buffer<HSLstruct> > vec(numpics);//,Buffer<HSLstruct>(GARGOYLE_X,GARGOYLE_Y));
    vector<Sensor> svec;
    //vector< Buffer<bool> > marked(numpics);//,Buffer<bool>(GARGOYLE_X,GARGOYLE_Y));

    //cout<<"READY";
    //cin.get();
    // Init marked array

    for (int i=0; i<=numpics-1; i++)
    {
        for (int yy=0; yy<=GARGOYLE_Y-1; yy++)
        {
            for (int xx=0; xx<=GARGOYLE_X-1; xx++)
            {
                marked[i].at(xx,yy)=false;
            }
        }
    }

    //cout<<"Gih!";
    //cin.get();

    WorldSpace one;
    one.fill_coordinates(30,30,30);
    Voxel vox1=one.world[10][10][0];
    Voxel vox2=one.world[0][0][0];
    Voxel vox3=one.world[0][20][0];
    Voxel vox4=one.world[20][0][0];
    Voxel vox5=one.world[20][20][0];
    
    //cout<<"Almost";
    //cin.get();

    RGB_BufferManager bman;

    // Test part starts
    //Buffer<RGB> testrgb(&test);
    //bman.assign_buffer(&testrgb);
    //bman.copy_from_image(&test);
    //bufptr=&testrgb;
    // Test part ends


    for (int i=1; i<=numpics; i++)
    {
        char filename[30]="K:\\Datasets\\Gargoyle";
        char dum[4];

        //filename[8]='\0';
        itoa(i,dum,10);
        strcat(filename,dum);
        strcat(filename,".bmp");
        cout<<filename<<endl;

        x.byte_reader.reader.open(filename,ios::in|ios::binary);
        x.byte_reader.writer.open(filename,ios::in|ios::out|ios::binary);

        if (x.byte_reader.reader.is_open()==true)
        {
            cout<<"File could be opened...";
        }

        //Buffer<RGB> somergb(&x);
        //Buffer<HSLstruct> somehsl(&x);

        bman.assign_buffer(&somergb);
        bman.copy_from_image(&x);
        BufferConvertor::RGB_to_HSL_buffer(&somehsl,&somergb);

        vec[i-1].copy_from(&somehsl);

        x.byte_reader.writer.close();
        x.byte_reader.reader.close();
    }


    double radius=5000; // 1000 is nice
    int cnt=0;

    for (double ang=0; ang<=359; ang+=360./numpics,cnt++)
    {
        double xx=radius*cos(deg_to_rad(ang));
        double yy=radius*sin(deg_to_rad(ang));

        Coordinate oc(xx,yy,0);
        Coordinate tg(0,0,0);

        double A=0-xx;
        double B=0-yy;
        double C=0;

        Coordinate fc(xx+A*.0095,yy+B*.0095,0); //.3 is OK

        Sensor y;
        y.set(oc,fc,0.825,0.55);//6.6.4.4
        y.img_buffer_ptr=&vec[cnt];
        y.flag_buffer_ptr=&marked[cnt];

        cout<<"Focal plane at ("<<fc.get_x()<<","<<fc.get_y()<<",0)\n";
        svec.push_back(y);
    }


    /*
    Coordinate gih1(vox1.x,vox1.y,vox1.z);
    Coordinate gih2(vox2.x,vox2.y,vox2.z);
    Coordinate gih3(vox3.x,vox3.y,vox3.z);
    Coordinate gih4(vox4.x,vox4.y,vox4.z);
    Coordinate gih5(vox5.x,vox5.y,vox5.z);

    gih1=VoxelWorker::intersection_of(gih1,svec[0]);
    gih2=VoxelWorker::intersection_of(gih2,svec[0]);
    gih3=VoxelWorker::intersection_of(gih3,svec[0]);
    gih4=VoxelWorker::intersection_of(gih4,svec[0]);
    gih5=VoxelWorker::intersection_of(gih5,svec[0]);
    
    cout<<gih1.get_x()<<" "<<gih1.get_y()<<" "<<gih1.get_z()<<endl;
    cout<<gih2.get_x()<<" "<<gih2.get_y()<<" "<<gih2.get_z()<<endl;
    cout<<gih3.get_x()<<" "<<gih3.get_y()<<" "<<gih3.get_z()<<endl;
    cout<<gih4.get_x()<<" "<<gih4.get_y()<<" "<<gih4.get_z()<<endl;
    cout<<gih5.get_x()<<" "<<gih5.get_y()<<" "<<gih5.get_z()<<endl;
    */

    cout<<"Ready to carve...press [Ctrl-Brk] to abort, any other key to continue\n";
    cin.get();

    //for(int i=0; i<=0; i++)
    //do
    //{
        carved=0;
        complete=true;

        RGB green={0,255,0};

        // Test part starts
        /*
        Coordinate box[8];
        int op[2][2];

        int ex=0,ey=0;

        for (int i=0; i<=WORLD_Z-1; i++)
        {
            for (int j=0; j<=WORLD_Y-1; j++)
            {
                for (int k=0; k<=0; k++)
                {
                    VoxelWorker::bounded_intersection_of(one.world[i][j][k],svec[0],box);
                    VoxelWorker::find_rectangle(op,box);

                    //cout<<"("<<op[0][0]<<","<<op[0][1]<<")-(";
                    //cout<<op[0][1]<<","<<op[1][1]<<")"<<endl;

                    if (op[0][0]==op[1][0])
                    {
                        //cout<<":-("<<endl;
                        ex++;
                    }

                    if (op[0][1]==op[1][1])
                    {
                        //cout<<":-("<<endl;
                    ey++;
                    }

                    for (int u=op[0][0]; u<=op[1][0]; u++)
                    {
                        testrgb.at(GARGOYLE_X/2+u,GARGOYLE_Y/2-op[0][1])=green;
                        testrgb.at(GARGOYLE_X/2+u,GARGOYLE_Y/2-op[1][1])=green;
                    }

                    for (int u=op[0][1]; u<=op[1][1]; u++)
                    {
                        testrgb.at(GARGOYLE_X/2+op[0][0],GARGOYLE_Y/2-u)=green;
                        testrgb.at(GARGOYLE_X/2+op[1][0],GARGOYLE_Y/2-u)=green;
                    }
                }
            }
        }

        cout<<"ex="<<ex<<" "<<"ey="<<ey;

        */
// Test part ends

        //x_space_carve_inc(svec,one);
        x_space_carve_dec(svec,one);

        //y_space_carve_inc(svec,one);
        //y_space_carve_dec(svec,one);

        cout<<carved<<" pixels carved.\n";
    //}
    //while(complete==false);
    
    //ofstream bound("Bound.txt");
    cout<<"Stand by for voxel render procedure...\n";

    // Voxel rendering

    x.byte_reader.reader.open("K:\\Datasets\\Blank.bmp",ios::nocreate|ios::in|ios::binary);
    x.byte_reader.writer.open("K:\\Datasets\\Blank.bmp",ios::nocreate|ios::out|ios::binary);

    if (x.byte_reader.reader.is_open()==true)
    {
        cout<<"Output file could be opened...\n";
    }

    else
    {
        cout<<"Output file could not be opened...\n";
    }

    Buffer<RGB> buf(&x);
    RGB_BufferManager man1;
    man1.assign_buffer(&buf);
    man1.copy_from_image(&x);

    int g=0,h=0;

    RGB white={255,255,255};
    //RGB green={0,255,0};
    RGB black={0,0,0};

    cout<<"Clears buffers...\n";
    for (int yy=0; yy<=599; yy++)
    {
        for (int xx=0; xx<=799; xx++)
        {
            buf.at(xx,yy)=black;
        }
    }

    cout<<"Before drawing slices...\n";
    for (int yy=0; yy<=WORLD_Y-1; yy++)
    {
        //cout<<"Drawing slice "<<yy<<endl;

        for (int zz=0; zz<=WORLD_Z-1; zz++)
        {
            for (int xx=0; xx<=WORLD_X-1; xx++)
            {
                if (one.world[zz][yy][xx].carved==true)
                {
                    RGB black={0,0,0};
                    buf.at(xx+g*(WORLD_X-1),zz+h*(WORLD_Z-1))=black;
                    continue;
                }

                else
                {
                    //cout<<"Coloring...\n";

                    HSLstruct col=one.world[zz][yy][xx].color;
                    RGB color=ColorSpaceConvertor::HSL_to_uRGB(col);

                    buf.at(xx+g*(WORLD_X-1),zz+h*(WORLD_Z-1))=color;
                }
            }
        }

        g++;

        if (g>800/WORLD_X)
        {
            h++;
            g=0;
        }
    }

    cout<<"Before drawing grid...\n";
    // Draw grid
    for (int sy=0; sy<=599; sy+=60)
    {
        for (int sx=0; sx<=799; sx++)
        {
            buf.at(sx,sy)=green;
        }
    }

    for (int sx=0; sx<=799; sx+=60)
    {
        for (int sy=0; sy<=599; sy++)
        {
            buf.at(sx,sy)=green;
        }
    }
    // End drawing grid

    man1.copy_to_image(&x);

    x.byte_reader.reader.close();
    x.byte_reader.writer.close();
    //bound.close();

    cout<<"Tests completed...\n";

    // Test code starts
    //bman.assign_buffer(&testrgb);
    //bman.copy_to_image(&test);

    //test.byte_reader.reader.close();
    //test.byte_reader.writer.close();
    // Test code ends
    
    cin.get();
    return 0;
}


