#include "RuntimePool.h"


Comrade::IrisRuntime::IrisObjectPool::IrisObjectPool()
{
	std::cout<<"IRIS object pool initialising...please wait.\n";
}

Comrade::IrisRuntime::IrisObjectPool::~IrisObjectPool()
{
	std::cout<<"Object pool destroyed...\n";
}

