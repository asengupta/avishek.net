#include "HoughTransform.h"

Comrade::IrisXT::HoughTransformObject::HoughTransformObject()
{}

Comrade::IrisXT::HoughTransformObject::~HoughTransformObject()
{}

long int** Comrade::IrisXT::StraightLineDetector::return_array()
{
	return param_array;
}

Comrade::IrisXT::StraightLineDetector::StraightLineDetector()
{}

int Comrade::IrisXT::StraightLineDetector::return_rows()
{
    return rows;
}

int Comrade::IrisXT::StraightLineDetector::return_cols()
{
    return cols;
}

void Comrade::IrisXT::StraightLineDetector::allocate(int perp,int theta)
{
    cout<<"StraightLineDetector object created...\n";

    rows=perp;
    cols=theta;

    param_array=new long int*[rows];

    for (int i=0; i<=rows-1; i++)
    {
        param_array[i]=new long int[cols];
    }
    
    for (int i=0; i<=rows-1; i++)
    {
	    for (int j=0; j<=cols-1; j++)
	    {
		    param_array[i][j]=0;
	    }
    }
}

void Comrade::IrisXT::StraightLineDetector::deallocate()
{
    for (int i=0; i<=rows-1; i++)
    {
        delete[] param_array[i];
    }

    delete[] param_array;
}

Comrade::IrisXT::StraightLineDetector::StraightLineDetector(int perp_levels,int theta_levels)
{
    allocate(perp_levels,theta_levels);
}

void Comrade::IrisXT::StraightLineDetector::set_param(int perp_levels,int theta_levels)
{
    deallocate();
    allocate(perp_levels,theta_levels);
}

void Comrade::IrisXT::StraightLineDetector::transform(Buffer<RGB>* ip)
{
    deallocate();
    int l=ip->maxx;
    int b=ip->maxy;
    
    int h=abs(l)+abs(b);
    allocate(h,360);
	cout<<"Doing Hough Transform now...\n";
	
    for (int y=0; y<=ip->maxy-1; y++)
    {
	    for (int x=0; x<=ip->maxx-1; x++)
	    {
			RGB color=ip->at(x,y);
			
			if (color.red==255 && color.green==255 && color.blue==255)
		    {
			    for (int i=0; i<=359; i++)
				{	    
					double ang=deg_to_rad(i);
					double perp=x*cos(ang)+y*sin(ang);
				
					if (perp>=0 && perp<=h-1)
					{
						param_array[static_cast<int>(perp)][i]++;
					}
				}
			}
		}
	}
}

Comrade::IrisXT::StraightLineDetector::~StraightLineDetector()
{
    deallocate();
}

Comrade::IrisXT::BasicShapeDetector::BasicShapeDetector()
{
	change_sz=0;
}
			
void Comrade::IrisXT::BasicShapeDetector::build_shape_table
(Comrade::IrisFoundation::Buffer<Comrade::IrisFoundation::RGB>* shape_screen,
 int cx,int cy,int num_samples)
{
	using namespace Comrade::IrisFoundation;
 	ShapeSampler sampler;
	
	Buffer<RGB> op_buf(*shape_screen);
	
	edman.Canny(shape_screen,&op_buf,.009);

	sampler.sample(&op_buf,&shape_table,num_samples,cx,cy);
}

void Comrade::IrisXT::BasicShapeDetector::transform
	      (Comrade::IrisFoundation::Buffer<Comrade::IrisFoundation::RGB>* ip)
{
	using namespace Comrade::IrisFoundation;
	
	screen_array.reallocate(ip->maxx,ip->maxy);
  	
   	BufferManager<int> man;
 	
  	man.assign_buffer(&screen_array);
  	man.fill(0);
  	Buffer<RGB> op(*ip);
	edman.Canny(ip,&op,.25);
	
	int inc=360/shape_table.size();
 	
  	for (int yy=0; yy<=ip->maxy-1; ++yy)
	{
		for (int xx=0; xx<=ip->maxx-1; ++xx)
		{
			RGB color=op.at(xx,yy);
			
			if (color.red!=255 ||
				color.green!=255 ||
				color.blue!=255)
			{
   			    continue;
            }
            
            int cur=0;
			
   			for (unsigned int i=0; i<=shape_table.size()-1; ++i)
			{
				int actual=cur-180;
				//actual=(actual<0)?(actual+360):actual;
    
                int rx=xx+static_cast<int>((shape_table[i]+change_sz)*cos(deg_to_rad(actual)));
				int ry=yy-static_cast<int>((shape_table[i]+change_sz)*sin(deg_to_rad(actual)));
	
    			screen_array.at(rx,ry)++;
       			cur+=inc;
    		}
		}
	}
}

Comrade::IrisFoundation::Buffer<int>* Comrade::IrisXT::BasicShapeDetector::return_array()
{
	return (&screen_array);
}

Comrade::IrisXT::BasicShapeDetector::~BasicShapeDetector()
{

}


