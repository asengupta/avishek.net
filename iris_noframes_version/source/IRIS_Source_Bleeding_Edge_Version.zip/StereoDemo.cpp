#include <cstdlib>
#include <vector>
#include "BitmapStreamer.h"
#include "KernelMatrix.h"
#include "NonkernelAlgorithms.h"
#include "MiscRoutines.h"
#include "HoughTransform.h"
#include "AutomataEdge.h"
#include "AutomataSkeleton.h"
#include "EdgeDetectors.h"
#include "SpecialKernels.h"
#include "Correlator.h"

using namespace Comrade::IrisFoundation;
using namespace Comrade::IrisXT;
using namespace Comrade::Iris3D;
using namespace std;

#define IMAGE_X 320
#define IMAGE_Y 240

int main()
{
    BitmapStreamer x,y,z;
    x.byte_reader.reader.open("Left.bmp",ios::in|ios::nocreate|ios::binary);
    x.byte_reader.writer.open("Left.bmp",ios::out|ios::binary|ios::nocreate);

    y.byte_reader.reader.open("Right.bmp",ios::in|ios::binary|ios::nocreate);
    y.byte_reader.writer.open("Right.bmp",ios::out|ios::binary|ios::nocreate);

    z.byte_reader.reader.open("Blank.bmp",ios::in|ios::binary|ios::nocreate);
    z.byte_reader.writer.open("Blank.bmp",ios::out|ios::binary|ios::nocreate);

    if (x.byte_reader.reader.is_open()==true &&
        y.byte_reader.reader.is_open()==true &&
        z.byte_reader.reader.is_open()==true)
    {
        cout<<"Files could be opened...";
    }

    else
    {
        cout<<"Files could not be opened...";
        cin.get();
        return 0;
    }

    //assert(x.byte_reader.reader.is_open()==true);

    int ys=x.byte_reader.read_field(OFFSET,SZ_OFFSET);
    cout<<ys<<endl;
    int xsz=x.byte_reader.read_field(BMP_WIDTH,SZ_BMP_WIDTH);
    int ysz=x.byte_reader.read_field(BMP_HEIGHT,SZ_BMP_HEIGHT);
    int comp=x.byte_reader.read_field(COMPRESSION,SZ_COMPRESSION);
    
    cout<<"This is "<<xsz<<" "<<ysz<<".Compression is "<<comp<<endl;

    Buffer<RGB> ip_buf(&x);
    Buffer<RGB> op_buf(&y);
    Buffer<RGB> dmap(&z);

    RGB_BufferManager man1,man2,man3;

    man1.assign_buffer(&ip_buf);
    man2.assign_buffer(&op_buf);
    man3.assign_buffer(&dmap);

    man1.copy_from_image(&x);
    man2.copy_from_image(&y);

    int step_size=4;

    for (int y1=0; y1<=IMAGE_Y-1; y1++)
    {
        for (int x1=0; x1<=IMAGE_X-1; x1++)
        {
            //cout<<"Doing ("<<x1<<","<<y1<<")\n";

            int total=0;

            /*for (int i=y1; i<=y1+step_size; i++)
            {
                for (int j=x1; j<=x1+step_size; j++)
                {
                    if (op_buf.at(j,i).red==255 &&
                        op_buf.at(j,i).green==255 &&
                        op_buf.at(j,i).blue==255)
                    {
                        total++;
                    }
                }
            }

            double ratio=static_cast<double>(total)/(step_size*step_size);
            //cout<<total<<" "<<ratio<<endl;

            if (ratio<.1)
            {
                for (int i=y1; i<=y1+step_size; i++)
                {
                    for (int j=x1; j<=x1+step_size; j++)
                    {
                        dmap.at(j,i).red=255;
                        dmap.at(j,i).green==0;
                        dmap.at(j,i).blue=0;
                    }
                }

                continue;
            }*/

            vector<double> arr;

            for (int i=0; i<=IMAGE_X-1-x1; i++)
            {
                //cout<<"Now doing..."<<i<<endl;
                arr.push_back(correlate(&ip_buf,&op_buf,x1,y1,x1+step_size,y1+step_size,x1+i,y1));
            }

            /*for (int i=0; i<=arr.size()-1; i++)
            {
                cout<<arr[i]<<" ";
            }*/

            double min=arr[0];
            int minpos=0;
            //double threshold=min-arr[0];

            for (int i=1; i<=arr.size()-1; i++)
            {
                if (arr[i]<min)
                {
                    min=arr[i];
                    minpos=i;
                }
            }

            //cout<<"Minimum is at : "<<x1+minpos<<endl;
            unsigned char shade=static_cast<unsigned char>(255*(1-1./sqrt(minpos+1)));

            for (int i=y1; i<=y1+step_size; i++)
            {
                for (int j=x1; j<=x1+step_size; j++)
                {
                    dmap.at(j,i).red=
                    dmap.at(j,i).green=
                    dmap.at(j,i).blue=shade;
                }
            }
        }
    }

    man3.copy_to_image(&z);

    x.byte_reader.writer.close();
    x.byte_reader.reader.close();

    y.byte_reader.writer.close();
    y.byte_reader.reader.close();

    cout<<"\nProcessing complete...\n";

    cin.get();

    return 0;
}


