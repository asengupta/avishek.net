#include <cstring>
#include "BufferConvertor.h"
#include "ModelBuilder.h"
#include "QuadtreeCore.h"
#include "Vert3D.h"
#include "QuadtreeSegmenter.h"
#include "ShapeSampler.h"
#include "SequenceAnalyser.h"

using namespace Comrade::IrisFoundation;
using namespace Comrade::IrisXT;
using namespace Comrade::Iris3D;
using namespace std;

bool belongs(Rectangle rect,Coordinate coord);

int main()
{
    BitmapStreamer x,y;
    x.byte_reader.reader.open("somechair.bmp",ios_base::in);
    x.byte_reader.writer.open("somechair.bmp",ios_base::in|ios_base::out);

    y.byte_reader.reader.open("blank.bmp",ios_base::in);
    y.byte_reader.writer.open("blank.bmp",ios_base::in|ios::out);

    if (x.byte_reader.reader.is_open()==true &&
        x.byte_reader.writer.is_open()==true &&
        y.byte_reader.reader.is_open()==true &&
        y.byte_reader.writer.is_open()==true)
    {
        cout<<"Files could be opened...";
    }

    else
    {
        cout<<"Files could not be opened...";

        cin.get();
        return 0;
    }

    Buffer<RGB> ip_buf(&x),op_buf(&y);
    RGB_BufferManager man1,man2;
    man1.assign_buffer(&ip_buf);
    man2.assign_buffer(&op_buf);
    man1.copy_from_image(&x);

    RGB black={0,0,0};
    
    Rectangle start={0,0,639,479,black};

    Tree<Rectangle,Coordinate> oak(start);
    oak.set_subsethood_fn(belongs);

    QuadtreeSegmenter seger;
    seger.minx=seger.miny=10;
    seger.threshold=300;

    seger.build_quadtree(&oak,&ip_buf);
    seger.draw_quadtree(&oak,&op_buf);

    cout<<"Done...\n";

    //TreeNode<int>* res=oak.locate(1);

    //res->add_branch(3);
    //res->add_branch(2);
    //res=oak.locate(3);
    //res->add_branch(4);
    //oak.locate(4);

    man2.copy_to_image(&y);

    x.byte_reader.reader.close();
    x.byte_reader.writer.close();

    y.byte_reader.reader.close();
    y.byte_reader.writer.close();

    cout<<"Quadtree built...\n";

    cin.get();
    return 0;
}

bool belongs(Rectangle rect,Coordinate coord)
{
    if (coord.get_x()>=rect.x1 &&
        coord.get_y()>=rect.y1 &&
        coord.get_x()<=rect.x2 &&
        coord.get_y()<=rect.y2)
    {
        return true;
    }

    else
    {
        return false;
    }
}



