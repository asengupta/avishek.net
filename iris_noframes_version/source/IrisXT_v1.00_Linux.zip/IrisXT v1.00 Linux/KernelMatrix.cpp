#include "KernelMatrix.h"

Comrade::IrisXT::KernelMatrix::KernelMatrix(int r,int c)
{
    matrix=new double*[r];

    for (int i=0; i<=c-1; i++)
    {
        matrix[i]=new double[c];
    }

    xsize=c;
    ysize=r;
}

void Comrade::IrisXT::KernelMatrix::set_values(double* arr)
{
    int u=0;

    for (int y=0; y<=xsize-1-1; y++)
    {
        for (int x=0; x<=xsize-1; x++)
        {
            matrix[y][x]=arr[u];
            u++;
        }
    }
}

Comrade::IrisXT::KernelMatrix::~KernelMatrix()
{
       for (int y=0; y<=ysize-1; y++)
       {
            delete[] matrix[y];
       }

       delete[] matrix;
}

Comrade::IrisXT::KernelOperator::KernelOperator()
{
    factor=1;
    cout<<"KernelOperator object created...\n";
}

// Deprecated, do NOT use this function. You can get by without it.
// ****************************************************************
//void KernelOperator::set_bounds(int x, int y)
//{
//    xsz=x;
//    ysz=y;
//}
// ****************************************************************

void Comrade::IrisXT::KernelOperator::set_bounds(BitmapStreamer* bmp_reader)
{
    reader=bmp_reader;

    xsz=reader->byte_reader.read_field(BMP_WIDTH,SZ_BMP_WIDTH);
    ysz=reader->byte_reader.read_field(BMP_HEIGHT,SZ_BMP_HEIGHT);
}

void Comrade::IrisXT::KernelOperator::convolve()
{
    convolve(0,0,xsz-1,ysz-1);
}

void Comrade::IrisXT::KernelOperator::convolve(int x1,int y1,int x2,int y2)
{
    //Gollum thief("IRIS-profile.txt");

    //clock_t start=clock();
    //cout<<"Start:"<<start<<endl<<"CLOCKS_PER_SEC is "<<CLOCKS_PER_SEC<<endl<<endl;

    RGB val;
    HSLstruct cur_HSLtemp;
    RGBstruct cur_RGBtemp;

    //thief.log_now("\n1) Creating temporary HSL buffer...");

    /* Create temporary HSL buffer */
    HSLstruct** hsl_ip=new HSLstruct*[ysz];

    for (int i=0; i<=ysz-1; i++)
    {
        hsl_ip[i]=new HSLstruct[xsz];
    }

    /* Copy the image into the RGB buffer and initialise HSL ip buffer */
    //thief.log_now("2) Constructing HSL version of image...");

    //reader->goto_start();

    for (int y=0; y<=ysz-1; y++)
    {
        for (int x=0; x<=xsz-1; x++)
        {
            val=ip_buffer[y][x];
            op_buffer[y][x]=val;

            RGBstruct temp={val.red/255.,val.green/255.,val.blue/255.};
            HSLstruct result=ColorSpaceConvertor::RGB_to_HSL(temp);
            hsl_ip[y][x]=result;
        }
    }

    //thief.log_now("3) Convolving...");

    int k_half_x=(rgb_kernel->xsize-1)/2;
    int k_half_y=(rgb_kernel->ysize-1)/2;

    int kernel_x=rgb_kernel->xsize;
    int kernel_y=rgb_kernel->ysize;

    double current_coefficient=0;
    double current_luminance=0, sum_luminance=0;

    for (int y=y1; y<=y2; y++)
    {
        for (int x=x1; x<=x2; x++)
        {
            cur_HSLtemp=hsl_ip[y][x];
            sum_luminance=0;

            int cand_x=x-k_half_x;
            int cand_y=y-k_half_y;

            for (int yy=0; yy<=kernel_y-1; yy++)
            {
                for (int xx=0; xx<=kernel_x-1; xx++)
                {
                    int fx=cand_x+xx;
                    int fy=cand_y+yy;

                    if (fx>=0 && fx<=xsz-1 && fy>=0 && fy<=ysz-1)
                    {
                        current_luminance=hsl_ip[fy][fx].luminance;
                        current_coefficient=rgb_kernel->matrix[(kernel_y-1)-yy][(kernel_x-1)-xx];
                        sum_luminance+=(current_luminance*current_coefficient);
                    }
                }
            }

            sum_luminance/=factor;

            sum_luminance=(sum_luminance>1)?1:sum_luminance;
            sum_luminance=(sum_luminance<0)?0:sum_luminance;

            cur_HSLtemp.luminance=sum_luminance;
            cur_RGBtemp=ColorSpaceConvertor::HSL_to_RGB(cur_HSLtemp);

            op_buffer[y][x].red=static_cast<unsigned char>(cur_RGBtemp.red*255);
            op_buffer[y][x].green=static_cast<unsigned char>(cur_RGBtemp.green*255);
            op_buffer[y][x].blue=static_cast<unsigned char>(cur_RGBtemp.blue*255);
        }
    }

    //thief.log_now("5) Deleting temporary HSL buffer...");

    /* Delete the temporary HSL buffer */
    for (int i=0; i<=ysz-1; i++)
    {
        delete[] hsl_ip[i];
    }

    delete[] hsl_ip;

    //thief.log_now("6) Convolution complete.");
}

Comrade::IrisXT::KernelOperator::~KernelOperator()
{}


