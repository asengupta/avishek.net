#ifndef HOUGH_TRANSFORM_H
#define HOUGH_TRANSFORM_H

#include <vector>
#include "newmath.h"
#include "EdgeDetectors.h"
#include "ShapeSampler.h"

namespace Comrade {
    namespace IrisXT {

using namespace Comrade::IrisFoundation;

class HoughTransformObject
{
private:

public:     HoughTransformObject();
            virtual void transform(Buffer<RGB>* ip)=0;
            virtual ~HoughTransformObject();
};

class StraightLineDetector:public HoughTransformObject
{
private:    int rows,cols;
            long int** param_array;

			void allocate(int perp,int theta);
            void deallocate();

public:     StraightLineDetector(int perp_levels,int theta_levels);
            StraightLineDetector();

            int return_rows();
            int return_cols();
            
            long int** return_array();
			void set_param(int perp_levels,int theta_levels);
            
            void transform(Buffer<RGB>* ip);

            ~StraightLineDetector();
};

class BasicShapeDetector:public HoughTransformObject
{
private:	Buffer<int> screen_array;
			EdgeDetectorManager edman;
			
public:		int change_sz;
			std::vector<double> shape_table;
			
			BasicShapeDetector();
			
   			void build_shape_table(Buffer<RGB>* shape_screen,
      							   int cx,int cy,int num_samples);
			
   			void transform(Buffer<RGB>* ip);
			Buffer<int>* return_array();
			
   			~BasicShapeDetector();
};

}
}

#endif


