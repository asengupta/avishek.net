#ifndef GOLLUM_H
#define GOLLUM_H

#include <iostream>
#include <fstream>
#include <vector>
#include <ctime>
#include <string>

#define CHECKPOINT 1
#define TIME_COUNTER_START 2
#define TIME_COUNTER_END 3

struct RecordUnit
{
    int type;
    string description;
    clock_t time_count;
};

class Gollum
{
protected:  vector<RecordUnit> storage;
            char session_details[150];
            char filename[20];
            ofstream writer;
            clock_t start_time;
            bool is_logging;

public:     Gollum(char* name);
            void label(char* dat);
            void end();
            void start_track(char* desc);
            void end_track();
            void log_now(char* desc);
            ~Gollum();
};

#endif



