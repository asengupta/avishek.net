#include "QuadtreeCore.h"

// Any nontemplate code goes here


