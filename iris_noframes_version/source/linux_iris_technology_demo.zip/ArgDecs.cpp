#include "ArgDecs.h"

Comrade::IrisRuntime::Argument::Argument()
{
    is_valid=false;
}


